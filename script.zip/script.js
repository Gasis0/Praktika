document.getElementById('toggle-theme').addEventListener('click', function() {
    document.body.classList.toggle('dark-theme');
});
let images = ['foto_3.png', 'foto_5.png', 'foto_6.png'];
let currentImageIndex = 0;
if (document.getElementById('change-image')) {
    document.getElementById('change-image').addEventListener('click', function() {
        currentImageIndex = (currentImageIndex + 1) % images.length;
        document.getElementById('main-image').src = images[currentImageIndex];
    });
}

// Обработка формы регистрации (для примера, просто предотвращаем отправку)
if (document.getElementById('registration-form')) {
    document.getElementById('registration-form').addEventListener('submit', function(event) {
        event.preventDefault();
        alert('Регистрация успешна!');
        // Здесь можно добавить логику для обработки регистрации
    });
}
